MMDB 2.0.1 Windows 更新目录占用修复

用于旧版更新报 EPERM / EBUSY，rename scripts -> .updates/backup-.../scripts。

1. 退出 MMDB 菜单。
2. 解压本包到原安装根目录（MMDB.cmd 所在目录）。
   确认覆盖 tools/release-update.mjs，不要解压到 scripts 目录。
3. 重开 MMDB.cmd，选 2“更新全部”。
4. 更新成功后退出并重开菜单；网页模式按提示更新油猴脚本、刷新 AI Studio。

本补丁仅替换更新器，保留配置与凭证；不包含完整新版程序。
不要将本 ZIP 作为完整发布包传给更新命令。

修复原理：保留现有程序目录，逐文件备份与替换；废弃文件同样备份，失败时恢复。
