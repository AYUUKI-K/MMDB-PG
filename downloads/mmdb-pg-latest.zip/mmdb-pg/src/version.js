export const MMDB_VERSION='1.2.13';
